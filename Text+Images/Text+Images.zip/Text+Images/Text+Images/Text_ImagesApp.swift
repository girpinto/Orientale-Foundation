//
//  Text_ImagesApp.swift
//  Text+Images
//
//  Created by Girolamo Pinto on 14/10/2020.
//

import SwiftUI

@main
struct Text_ImagesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct Text_ImagesApp_Previews: PreviewProvider {
    static var previews: some View {
        /*@START_MENU_TOKEN@*/Text("Hello, World!")/*@END_MENU_TOKEN@*/
    }
}
