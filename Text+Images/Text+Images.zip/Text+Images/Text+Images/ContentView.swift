//
//  ContentView.swift
//  Text+Images
//
//  Created by Girolamo Pinto on 14/10/2020.
//

import SwiftUI

// This is the ContentView. In this view you'll insert everything you need in this particular view, such as Buttons, Text, Images and so on...
struct ContentView: View {
    var body: some View {
        VStack{
            CircleImageContentView(image: "Trivium_-_Shogun")
            TextView(songTitle: "Shogun", bandName: "Trivium", albumName: "Shogun")
        }
        .padding()
        // with this line of code you can see how it appear your view on the device you want to develop
        .previewDevice("iPhone 11")
    }
}

// This is the ContentView_Preview. Basically this will display everything you write in ContentView struct.
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
