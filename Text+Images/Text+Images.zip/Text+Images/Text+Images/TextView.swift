//
//  TextView.swift
//  Text+Images
//
//  Created by Girolamo Pinto on 14/10/2020.
//

import SwiftUI

struct TextView: View{
    var songTitle : String
    var bandName : String
    var albumName : String
    var body: some View{
        VStack(alignment: .center, spacing: /*@START_MENU_TOKEN@*/nil/*@END_MENU_TOKEN@*/, content: {
            // To display a label in your view you have just to type Text("Here the text you want to display")
            Text(songTitle)
                // When you type .padding() you're setting constraints inside your view for a specific object. Basically you're saying to the label "This is the title" : You have to stay there and you can't move. The .all it means that around the object you're creating edges
                // You can choose the font
                .font(.title)
                // and the color
                .foregroundColor(.black)
            // the position
            //.position(x: 200.0, y: 400.0)
            HStack{
                Text(bandName)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                
                Text(" - ")
                
                Text(albumName)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        })
    }
}

struct TextView_Previews: PreviewProvider {
    static var previews: some View {
        TextView(songTitle: "Title", bandName: "Band", albumName: "Album")
    }
}
