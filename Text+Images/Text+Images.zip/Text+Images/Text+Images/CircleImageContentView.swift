//
//  CircleImageContentView.swift
//  Text+Images
//
//  Created by Girolamo Pinto on 14/10/2020.
//

import SwiftUI

struct CircleImageContentView: View {
    var image : String
    var body: some View{
        Image(image).resizable()
            .clipShape(Circle())
            .frame(width: 200, height: 200, alignment: .center)
    }
}

struct CircleImageContentView_Previews: PreviewProvider {
    static var previews: some View {
        CircleImageContentView(image: "Trivium_-_Shogun")
    }
}
