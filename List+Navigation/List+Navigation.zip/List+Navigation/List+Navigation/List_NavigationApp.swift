//
//  List_NavigationApp.swift
//  List+Navigation
//
//  Created by Girolamo Pinto on 15/10/2020.
//

import SwiftUI

@main
struct List_NavigationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
