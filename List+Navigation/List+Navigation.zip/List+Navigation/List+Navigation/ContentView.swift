//
//  ContentView.swift
//  List+Navigation
//
//  Created by Girolamo Pinto on 15/10/2020.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        LandmarkList(landmarkData: listOfSongs)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewDevice("iPhone 11")
    }
}
