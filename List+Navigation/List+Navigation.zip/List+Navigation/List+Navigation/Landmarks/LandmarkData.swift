//
//  LandmarkData.swift
//  List+Navigation
//
//  Created by Girolamo Pinto on 15/10/2020.
//

import Foundation

class LandmarkData: ObservableObject{
    var songList: [Landmark]
    
    init(songList: [Landmark]) {
        self.songList = songList
    }
}

let listOfSongs = LandmarkData(songList: [
    Landmark(id: 001, songTitle: "Shogun", albumName: "Shogun", artist: "Trivium", category: .metal),
    Landmark(id: 002, songTitle: "People Are Strange", albumName: "Strange Days", artist: "The doors", category: .rock),
    Landmark(id: 003, songTitle: "Hero", albumName: "Awake", artist: "Skillet", category: .metal),
    Landmark(id: 004, songTitle: "Demon's Are a Girl Best Friend", albumName: "The Sacrament of Sin", artist: "Powerwolf", category: .metal),
    Landmark(id: 005, songTitle: "Time Bomb", albumName: "New Empire, Vol. 1", artist: "Hollywood Undead", category: .rock),
    Landmark(id: 006, songTitle: "The Sin and the Sentence", albumName: "The Sin and the Sentence", artist: "Trivium", category: .metal),
    Landmark(id: 007, songTitle: "You Give Love a Bad Name", albumName: "Slippery When Wet", artist: "Bon Jovi", category: .rock),
    Landmark(id: 008, songTitle: "Throes of Perdition", albumName: "Shogun", artist: "Trivium", category: .metal),
    Landmark(id: 009, songTitle: "Lose Yourself", albumName: "Courtain Call", artist: "Eminem", category: .rap),
    Landmark(id: 010, songTitle: "Like Toy Soldiers", albumName: "Encore", artist: "Eminem", category: .rap)
])
