//
//  LandmarkRow.swift
//  List+Navigation
//
//  Created by Girolamo Pinto on 15/10/2020.
//

import SwiftUI

struct LandmarkRow: View {
    var landmark: Landmark
    
    var body: some View {
        HStack{
            CircleImage(landmark: landmark)
            VStack{
                Text(landmark.songTitle)
                    .frame(width: 200, height: 20, alignment: .leading)
    
                Text("\(landmark.artist) " + " - " + "\(landmark.albumName)")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .frame(width: 200, height: 10, alignment: .leading)
            }
            Spacer()
        }
    }
}

struct LandmarkRow_Previews: PreviewProvider {
    static var previews: some View {
        Group{
        LandmarkRow(landmark: listOfSongs.songList[0])
        LandmarkRow(landmark: listOfSongs.songList[1])
        }
        .previewLayout(.fixed(width: 300, height: 70))
    }
}
