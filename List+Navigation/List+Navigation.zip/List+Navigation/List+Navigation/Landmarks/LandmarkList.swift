//
//  LandmarkList.swift
//  List+Navigation
//
//  Created by Girolamo Pinto on 15/10/2020.
//

import SwiftUI

struct LandmarkList: View {
    @StateObject var landmarkData: LandmarkData
    var body: some View {
        NavigationView{
            List(landmarkData.songList){ landmark in
                NavigationLink(
                    destination: LandmarkDetail(landmark: landmark),
                    label: {
                        LandmarkRow(landmark: landmark)
                })
            }
            .navigationBarTitle(Text("Music"), displayMode: .large)
        }
    }
}

struct LandmarkList_Previews: PreviewProvider {
    static var previews: some View {
        LandmarkList(landmarkData: listOfSongs)
    }
}
