//
//  LandmarkDetail.swift
//  List+Navigation
//
//  Created by Girolamo Pinto on 15/10/2020.
//

import SwiftUI

struct LandmarkDetail: View {
    @State var landmark : Landmark
    @State var buttonImage = Image(systemName: "play.fill")
    @State var minutes : Double = 0.0
    var body: some View {
        NavigationView{
            VStack{
                Image(landmark.albumName).resizable()
                    .frame(width: 210, height: 210, alignment: .center)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
                    .offset(y: -60)
                Text("\(landmark.songTitle)" + " - " + "\(landmark.albumName)")
                    .font(.title)
                    .offset(y: -60)
                Text(landmark.artist)
                    .foregroundColor(.gray)
                    .offset(y: -60)
                
                Slider(value: $minutes, in: 0.00...7.00, step: 0.1)
                    .offset(y : -50)
                    .frame(width: 250, height: 0, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Text("\(minutes, specifier: "%.2f")")
                    .offset(y: -30)
                HStack{
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                        Image(systemName: "backward.fill").resizable()
                            .frame(width: 40, height: 40, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.black)
                            .offset(x: -50)
                    })
                    Button(action: {
                        if buttonImage == Image(systemName: "play.fill"){
                            buttonImage = Image(systemName: "pause.fill")
                        }
                        else if buttonImage == Image(systemName: "pause.fill"){
                            buttonImage = Image(systemName: "play.fill")
                        }
                    }, label: {
                        buttonImage.resizable()
                            .foregroundColor(.black)
                            .frame(width: 40, height: 40, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        
                    })
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                        Image(systemName: "forward.fill").resizable()
                            .frame(width: 40, height: 40, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.black)
                            .offset(x: +50)
                    })
                }
            }
            .navigationBarTitle(Text("Detail"), displayMode: .large)
        }
    }
}

struct LandmarkDetail_Previews: PreviewProvider {
    static var previews: some View {
        LandmarkDetail(landmark: listOfSongs.songList[0])
            .previewDevice("iPhone 11")
    }
}
