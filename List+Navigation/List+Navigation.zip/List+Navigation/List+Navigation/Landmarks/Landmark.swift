//
//  Landmark.swift
//  List+Navigation
//
//  Created by Girolamo Pinto on 15/10/2020.
//

import SwiftUI

struct Landmark: Identifiable {
    var id : Int
    var songTitle : String
    var albumName : String
    var artist : String
    var category : Category
    
    enum Category: String, CaseIterable, Codable, Hashable{
        case rock = "Rock"
        case metal = "Metal"
        case rap = "Rap"
    }
}

extension Landmark{
    var albumImage: Image{
        Image(albumName)
    }
}
