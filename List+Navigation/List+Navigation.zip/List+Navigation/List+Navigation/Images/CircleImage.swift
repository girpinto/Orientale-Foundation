//
//  CircleImage.swift
//  List+Navigation
//
//  Created by Girolamo Pinto on 15/10/2020.
//

import SwiftUI

struct CircleImage: View {
    @State var landmark : Landmark
    var body: some View {
        Image(landmark.albumName).resizable()
            .clipShape(Circle())
            .frame(width: 50, height: 50, alignment: .center)
    }
}

struct CircleImage_Previews: PreviewProvider {
    static var previews: some View {
        CircleImage(landmark: listOfSongs.songList[0])
    }
}
