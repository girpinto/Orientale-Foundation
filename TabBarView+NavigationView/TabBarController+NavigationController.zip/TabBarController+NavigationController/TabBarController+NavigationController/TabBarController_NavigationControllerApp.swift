//
//  TabBarController_NavigationControllerApp.swift
//  TabBarController+NavigationController
//
//  Created by Girolamo Pinto on 14/10/2020.
//

import SwiftUI

@main
struct TabBarController_NavigationControllerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
