//
//  TabBarView.swift
//  TabBarController+NavigationController
//
//  Created by Girolamo Pinto on 14/10/2020.
//

import SwiftUI

struct TabBarView: View {
    //MARK: - Proprerties
    var firstItemString : String
    var secondItemString : String
    var thirdItemString : String
    var fourthItemString : String
    
    //MARK: - Initialization
    init(firstItemString: String, secondItemString: String, thirdItemString: String, fourthItemString: String){
        self.firstItemString = firstItemString
        self.secondItemString = secondItemString
        self.thirdItemString = thirdItemString
        self.fourthItemString = fourthItemString
        UITabBar.appearance().isTranslucent = true
        //Uncomment to change background tab bar color 
        //UITabBar.appearance().barTintColor = .black
    }
    
    //MARK: - Body
    var body: some View {
        TabView{
            NavigationView{
                Text("Content")
                    .navigationTitle(firstItemString)
            }
            .tabItem {
                Image(systemName: "star.fill")
                Text(firstItemString)
            }
            NavigationView{
                Text("")
                    .navigationTitle(secondItemString)
            }
            .tabItem {
                Image(systemName: "clock.fill")
                Text(secondItemString)
            }
            NavigationView{
                Text("")
                    .navigationTitle(thirdItemString)
            }
            .tabItem {
                Image(systemName: "person.fill")
                Text(thirdItemString)
            }
            NavigationView{
                Text("")
                    .navigationTitle(fourthItemString)
            }
            .tabItem {
                Image(systemName: "tv.fill")
                Text(fourthItemString)
            }
        }
        //this will allow the status bar to share the translucency of the nav bar.
        .edgesIgnoringSafeArea(.top)
    }
}

struct TabBarView_Previews: PreviewProvider {
    static var previews: some View {
        TabBarView(firstItemString: "First", secondItemString: "Second", thirdItemString: "Third", fourthItemString: "Fourth")
    }
}
