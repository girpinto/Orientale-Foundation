//
//  ContentView.swift
//  TabBarController+NavigationController
//
//  Created by Girolamo Pinto on 14/10/2020.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabBarView(firstItemString: "Favourites", secondItemString: "Recents", thirdItemString: "Contacts", fourthItemString: "Mail")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
