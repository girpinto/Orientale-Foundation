//
//  ContentView.swift
//  Buttons
//
//  Created by Girolamo Pinto on 14/05/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            NeumorphicButtonView()
                .padding(100)
            
            VStack{
                CircleButton()
                    .padding(10)
                
                Text("Long press Gesture")
                    .font(.title)
            }
            .padding(100)
            
            SwipeButton()
                .padding(30)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(#colorLiteral(red: 0.8293729424, green: 0.8888757229, blue: 1, alpha: 1)))
        .edgesIgnoringSafeArea(.all)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
