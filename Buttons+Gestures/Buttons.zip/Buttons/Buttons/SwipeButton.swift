//
//  SwipeButton.swift
//  Buttons
//
//  Created by Girolamo Pinto on 14/05/21.
//

import SwiftUI

struct SwipeButton: View {
    @State var viewState : CGSize = CGSize.zero
    var body: some View {
        VStack{
            Text("Swipe")
                .font(.system(size: 20, weight: .semibold, design: .rounded))
                .frame(width: 200, height: 60)
                .background(
                    ZStack {
                        Color(#colorLiteral(red: 0.7607843137, green: 0.8156862745, blue: 0.9254901961, alpha: 1))
                        
                        RoundedRectangle(cornerRadius: 16.0, style: .continuous)
                            .foregroundColor(.white)
                            .blur(radius: 4)
                            .offset(x: -8, y: -8)
                        
                        RoundedRectangle(cornerRadius: 16.0, style: .continuous)
                            .fill(
                                LinearGradient(gradient: Gradient(colors: [Color(#colorLiteral(red: 0.8293729424, green: 0.8888757229, blue: 1, alpha: 1)), Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0))]), startPoint: .topLeading, endPoint: .bottomTrailing)
                            )
                            .padding(2)
                            .blur(radius: 2)
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 16.0, style: .continuous)
                                .foregroundColor(Color(#colorLiteral(red: 0.2768166363, green: 0.01324164774, blue: 0.9894741178, alpha: 1)))
                                .frame(width: 250)
                                .offset(x: -160, y: 0)
                                .shadow(color: Color(#colorLiteral(red: 0.698622942, green: 0.748742342, blue: 0.8514878154, alpha: 1)),radius: 10, x: 10, y: 10)
                                .shadow(color: Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)), radius: 20, x: -20, y: -20)
                                .shadow(color: Color(#colorLiteral(red: 0.7607843137, green: 0.8156862745, blue: 0.9254901961, alpha: 1)), radius: 20, x: 20, y: 20)
                            
                            Image(systemName: "swift")
                                .font(.system(size: 44))
                                .frame(width: 200, height: 60, alignment: .leading)
                                .foregroundColor(.black)
                                .cornerRadius(15)
                        }
                        .offset(x: self.viewState.width)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .gesture(
                            DragGesture()
                                .onChanged{ value in
                                    if self.viewState.width > 200{
                                        self.viewState = .zero
                                    }
                                    else{
                                        self.viewState = value.translation
                                    }
                                }
                                .onEnded{ value in
                                    self.viewState = .zero
                                }
                        )
                    }
                )
                .clipShape(RoundedRectangle(cornerRadius: 16.0, style: .continuous))
                .shadow(color: Color(#colorLiteral(red: 0.806425035, green: 0.8642808795, blue: 0.9828751683, alpha: 1)), radius: 20, x: 20, y: 20)
                .shadow(color: Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)), radius: 20, x: -20, y: -20)
                .shadow(color: Color(#colorLiteral(red: 0.7607843137, green: 0.8156862745, blue: 0.9254901961, alpha: 1)), radius: 20, x: 20, y: 20)
        }
    }
}

struct SwipeButton_Previews: PreviewProvider {
    static var previews: some View {
        SwipeButton()
    }
}
