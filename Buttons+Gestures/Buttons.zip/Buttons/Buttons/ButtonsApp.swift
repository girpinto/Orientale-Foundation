//
//  ButtonsApp.swift
//  Buttons
//
//  Created by Girolamo Pinto on 14/05/21.
//

import SwiftUI

@main
struct ButtonsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
