//
//  NeumorphicButtonView.swift
//  Buttons
//
//  Created by Girolamo Pinto on 14/05/21.
//

import SwiftUI

struct NeumorphicButtonView: View {
    @State var tap : Bool = false
    var body: some View {
        VStack{
            Text("Tap gesture")
                .font(.system(size: 20, weight: .semibold, design: .rounded))
                .frame(width: 200, height: 60)
                .background(
                    ZStack {
                        Color(#colorLiteral(red: 0.7607843137, green: 0.8156862745, blue: 0.9254901961, alpha: 1))
                        
                        RoundedRectangle(cornerRadius: 16.0, style: .continuous)
                            .foregroundColor(.white)
                            .blur(radius: 4)
                            .offset(x: -8, y: -8)
                        
                        RoundedRectangle(cornerRadius: 16.0, style: .continuous)
                            .fill(
                                LinearGradient(gradient: Gradient(colors: [Color(tap ? #colorLiteral(red: 0.8293729424, green: 0.8888757229, blue: 1, alpha: 1):#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)), Color(tap ? #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0):#colorLiteral(red: 0.8293729424, green: 0.8888757229, blue: 1, alpha: 1))]), startPoint: .topLeading, endPoint: .bottomTrailing)
                            )
                            .padding(2)
                            .blur(radius: 2)
                    }
                )
                .clipShape(RoundedRectangle(cornerRadius: 16.0, style: .continuous))
                .shadow(color: Color(tap ? #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1):#colorLiteral(red: 0.806425035, green: 0.8642808795, blue: 0.9828751683, alpha: 1)), radius: 20, x: 20, y: 20)
                .shadow(color: Color(tap ? #colorLiteral(red: 0.7607843137, green: 0.8156862745, blue: 0.9254901961, alpha: 1):#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)), radius: 20, x: -20, y: -20)
                .shadow(color: Color(#colorLiteral(red: 0.7607843137, green: 0.8156862745, blue: 0.9254901961, alpha: 1)), radius: 20, x: 20, y: 20)
                .scaleEffect(tap ? 1 : 1.2)
                .onTapGesture(perform: {
                    self.tap = true
                    print("Ho tappato il bottone")
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        self.tap = false
                    }
                })
        }
    }
}

struct NeumorphicButtonView_Previews: PreviewProvider {
    static var previews: some View {
        NeumorphicButtonView()
    }
}
