//
//  CircleButton.swift
//  Buttons
//
//  Created by Girolamo Pinto on 14/05/21.
//

import SwiftUI

struct CircleButton: View {
    @GestureState var tap : Bool = false
    @State var press : Bool = false
    var body: some View {
        ZStack{
            Image(systemName: "sun.max")
                .font(.system(size: 44, weight: .light))
                .offset(x: press ? -90 : 0, y: press ? -90 : 0)
                .rotation3DEffect(Angle(degrees: press ? 20 : 0), axis: (x: 10, y: -10, z: 0.0))
                .scaleEffect(press ? 0 : 1)
            
            Image(systemName: "moon")
                .font(.system(size: 44, weight: .light))
                .offset(x: press ? 0 : 90, y: press ? 0 : 90)
                .rotation3DEffect(Angle(degrees: press ? 0 : 20), axis: (x: -10, y: 10, z: 0.0))
                .scaleEffect(press ? 1 : 0)
        }
        .animation(.easeIn(duration: 0.3))
        .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
        .background(
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color(press ? #colorLiteral(red: 0.8293729424, green: 0.8888757229, blue: 1, alpha: 1):#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), Color(press ? #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1):#colorLiteral(red: 0.8293729424, green: 0.8888757229, blue: 1, alpha: 1))]), startPoint: .topLeading, endPoint: .bottomTrailing)
                
                Circle()
                    .stroke(Color.clear, lineWidth: 10)
                    .shadow(color: Color(press ? #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0):#colorLiteral(red: 0.7607843137, green: 0.8156862745, blue: 0.9254901961, alpha: 1)), radius: 3, x: -5, y: -5)
                
                Circle()
                    .stroke(Color.clear, lineWidth: 10)
                    .shadow(color: Color(press ? #colorLiteral(red: 0.7607843137, green: 0.8156862745, blue: 0.9254901961, alpha: 1):#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), radius: 3, x: 3, y: 3)
            }
        )
        .clipShape(Circle())
        .shadow(color: Color(press ? #colorLiteral(red: 0.7607843137, green: 0.8156862745, blue: 0.9254901961, alpha: 1):#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), radius: 20, x: -20, y: -20)
        .shadow(color: Color(press ? #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1):#colorLiteral(red: 0.7607843137, green: 0.8156862745, blue: 0.9254901961, alpha: 1)), radius: 20, x: -20, y: -20)
        .scaleEffect(tap ? 1 : 1.2)
        .animation(.easeInOut(duration: 0.3))
        .gesture(
            LongPressGesture().updating($tap){ currentState, gestureState, transaction in
                gestureState = currentState
            }
            .onEnded{ value in
                self.press.toggle()
            }
        )
    }
}

struct CircleButton_Previews: PreviewProvider {
    static var previews: some View {
        CircleButton()
    }
}
