//
//  MapViewApp.swift
//  MapView
//
//  Created by Girolamo Pinto on 15/05/21.
//

import SwiftUI

@main
struct MapViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
