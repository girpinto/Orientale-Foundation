//
//  Place.swift
//  MapView
//
//  Created by Girolamo Pinto on 18/05/21.
//

import SwiftUI
import MapKit

struct Place: Identifiable{
    var id = UUID().uuidString
    var place : CLPlacemark
}
