//
//  MapViewModel.swift
//  MapView
//
//  Created by Girolamo Pinto on 18/05/21.
//

///All Map Data goes here
import SwiftUI
import MapKit
import CoreLocation

class MapViewModel: NSObject,ObservableObject,CLLocationManagerDelegate{
    @Published var mapView = MKMapView()
    ///Region, It will setup based on location
    @Published var region : MKCoordinateRegion!
    
    ///Alert
    @Published var permissionDenied = false
    
    ///Map type
    @Published var mapType : MKMapType = .standard
    
    ///Text to search using search bar
    @Published var textToSearch = ""
    
    ///Searched places
    @Published var places : [Place] = []
    
    ///Updating map type
    func updateMapType(){
        if mapType == .standard{
            mapType = .hybrid
            mapView.mapType = mapType
        }
        else{
            mapType = .standard
            mapView.mapType = mapType
        }
    }
    
    ///Focus Location on user coordinate
    func focusLocation(){
        guard let _ = region else {
            return
        }
        mapView.setRegion(region, animated: true)
        mapView.setVisibleMapRect(mapView.visibleMapRect, animated: true)
    }
    
    ///Searching new location
    func searchQuery(){
        ///Clean array
        places.removeAll()
        
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = textToSearch
        
        ///Fetching the request
        MKLocalSearch(request: request).start{ (response, _) in
            guard let response = response else{
                return
            }
            
            self.places = response.mapItems.compactMap({ (item) -> Place? in
                return Place(place: item.placemark)
            })
        }
    }
    
    ///Pick search result
    
    func selectPlace(place: Place ){
        ///Showing pin on map
        textToSearch = ""
        
        guard let coordinate = place.place.location?.coordinate else{
            return
        }
        
        let pointAnnotation = MKPointAnnotation()
        pointAnnotation.coordinate = coordinate
        pointAnnotation.title = place.place.name ?? "No name"
        
        ///removing all old ones
        mapView.removeAnnotations(mapView.annotations)
         
        mapView.addAnnotation(pointAnnotation)
        
        ///Moving map to that location
        let coordinateRegion = MKCoordinateRegion(center: coordinate, latitudinalMeters: 10000, longitudinalMeters: 10000)
        
        mapView.setRegion(coordinateRegion, animated: true)
        mapView.setVisibleMapRect(mapView.visibleMapRect, animated: true)
    }
    
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        ///Checking permissions, if the user given consent about taking his location
        
        switch manager.authorizationStatus {
        case .denied:
            ///If the user did not give the permission to use his location
            permissionDenied.toggle()
        case .notDetermined:
            ///If the app don't know if the user give consent or not
            manager.requestWhenInUseAuthorization()
        case .authorizedWhenInUse:
            ///If the permission is given just when user uses the app
            manager.requestLocation()
        default:
            ()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        ///Error, try to create customized errors
        print(error.localizedDescription)
    }
    
    ///Getting user region
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else{
            return
        }
        
        self.region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 10000, longitudinalMeters: 10000)
        
        ///Now I update the map
        self.mapView.setRegion(self.region, animated: true)
        
        ///Smother animation
        self.mapView.setVisibleMapRect(self.mapView.visibleMapRect, animated: true)
    }
}
