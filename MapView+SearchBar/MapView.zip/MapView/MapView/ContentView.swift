//
//  ContentView.swift
//  MapView
//
//  Created by Girolamo Pinto on 15/05/21.
//

import SwiftUI
import CoreLocation

struct ContentView: View {
    @StateObject var mapData = MapViewModel()
    ///Location manager
    @State var locationManager = CLLocationManager()
    var body: some View {
        ZStack{
            ///The map itself
            MapView()
                ///I use it as environment object so it can be used inside subViews
                .environmentObject(mapData)
                .ignoresSafeArea(.all, edges: .all)
            
            VStack{
                VStack(spacing: 0){
                    HStack{
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        
                        TextField("Search location", text: $mapData.textToSearch)
                            .colorScheme(.light)
                    }
                    .padding(.vertical,10)
                    .padding(.horizontal)
                    .background(Color.white)
                    
                    if !mapData.places.isEmpty && mapData.textToSearch != ""{
                        ScrollView{
                            VStack(spacing: 15){
                                ForEach(mapData.places){place in
                                    
                                    Text(place.place.name ?? "")
                                        .foregroundColor(.black)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .padding(.leading)
                                        .onTapGesture {
                                            mapData.selectPlace(place: place)
                                        }
                                    
                                    Divider()
                                }
                            }
                            .padding(.top)
                        }
                        .background(Color.white)
                    }
                }
                .padding()
                Spacer()
                VStack{
                    Button(action: mapData.focusLocation, label: {
                        Image(systemName: "location.fill")
                            .font(.title2)
                            .padding(10)
                            .background(Color.primary)
                            .clipShape(Circle())
                    })
                    
                    Button(action: mapData.updateMapType, label: {
                        Image(systemName: mapData.mapType == .standard ? "network" : "map")
                            .font(.title2)
                            .padding(10)
                            .background(Color.primary)
                            .clipShape(Circle())
                    })
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding()
            }
        }
        .onTapGesture {
            self.dismissKeyboard()
        }
        .onAppear(perform: {
            ///Setting delegate
            locationManager.delegate = mapData
            locationManager.requestWhenInUseAuthorization()
        })
        ///Permission Denied Alert
        .alert(isPresented: $mapData.permissionDenied, content: {
            Alert(title: Text("Permission denied"), message: Text("Please enable permission in Settings"), dismissButton: .default(Text("Go to Settings"), action: {
                ///Redirecting user to settings
                UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)
            }))
        })
        .onChange(of: mapData.textToSearch, perform: { value in
            ///Searching new location typed by the user
            ///You can use your own delay to avoid continous search request
            let delay = 0.3
            
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                if value == mapData.textToSearch{
                    ///Search the location typed
                    self.mapData.searchQuery()
                }
            }
        })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
